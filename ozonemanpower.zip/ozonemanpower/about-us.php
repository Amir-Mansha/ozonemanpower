<?php include 'include/header.php';?>

        <!-- page-title -->
        <div class="cmt-page-title-row">
            <div class="cmt-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="page-title-heading">
                                <h2 class="title">About Our Compny</h2>
                                <p>Recuriter for Healthcare, Education, Hospitality,Petroleum, Construction,
                                    Transportation, Aviation, IT and more.
                                </p>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="index.php">Home</a>
                                </span>
                                <span>About Us</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                    
        </div>
        <!-- page-title end -->


    <!--site-main start-->
    <div class="site-main">

        
        <!--about-section-->
        <section class="cmt-row about_2-section clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-5 col-5 mr-lg-auto ml-lg-0 offset-3">
                        <div class="cmt-bg cmt-col-bgcolor-yes cmt-bgcolor-grey pt-25 pb-25 pl-25 pr-25 ml-80 res-991-ml-0">
                            <div class="cmt-col-wrapper-bg-layer cmt-bg-layer"></div>
                            <div class="layer-content">
                                <div class="cmt-bgcolor-white pt-60 pb-50 res-991-pt-50 res-991-pb-40">
                                    <div class="col-lg-12">
                                  <div class="ttm_single_image-wrapper ml_110 mr_200 res-575-mr_140">
                                        <img class="img-fluid" src="images/license.jpeg" alt="">
                                    </div>      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-12 col-xs-12">
                        <div class="pt-15 pr-30 mb_30 res-991-pr-0 res-991-pt-30">
                            <!-- section title -->
                            <div class="section-title">
                                <div class="title-header">
                                    <h5>why choose us</h5>
                                    <h2 class="title">Why Choose <strong>Ozone Manpower?</strong></h2>
                                </div>
                            </div><!-- section title end -->
                            <p>The foundation was established with a small idea that arose in the minds of its promoters in the year 1994! We skillfully guide applicants through their Visa process to any country in which they aspire to settle. </p>
                            <div class="pt-10 pr-15 res-991-pr-0">
                                <!-- featured-icon-box -->
                                <div class="featured-icon-box icon-align-before-content style2">
                                    <div class="featured-icon">
                                        <div class="cmt-icon cmt-icon_element-border cmt-icon_element-color-skincolor cmt-icon_element-size-lg cmt-icon_element-style-square"> 
                                            <i class="flaticon-policy"></i>
                                        </div>
                                    </div>
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5><a href="services-1.php">Accurate Guidance</a></h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>Skilled professionals are always ready to provide reliable services to our clients!</p>
                                        </div>
                                    </div>
                                </div><!-- featured-icon-box end -->
                                <!-- featured-icon-box -->
                                <div class="featured-icon-box icon-align-before-content style2">
                                    <div class="featured-icon">
                                        <div class="cmt-icon cmt-icon_element-border cmt-icon_element-color-skincolor cmt-icon_element-size-lg cmt-icon_element-style-square"> 
                                            <i class="flaticon-contract"></i>
                                        </div>
                                    </div>
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5><a href="services-1.php">Our Presence</a></h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>Branches are situated in major metro cities and overseas, always open for you!</p>
                                        </div>
                                    </div>
                                </div><!-- featured-icon-box end -->
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--about-section end-->


        <div class="row">
            <div class="col-md-12">
                <p style="margin-left: 20%; margin-right: 10%">Ozone Manpower obtained license in 2008 from Ministry of Labour, Manpower and Overseas Employment, Government of Pakistan, Manpower Recruitment to meet the growing requirements and growing trust of customers by providing quality and committed services to all its prestigious clients.</p>
                
                <p style="margin-left: 20%; margin-right: 10%">It is our explicit policy to serve customers who demand expectations in accordance with the highest standards of quality and lasting satisfaction. Our goal is to serve customers better and to achieve this we are continuously improving our business processes by working in teams and providing appropriate management of the work environment and quality tools, and in this way we have helped more than thousands of workers in projects of different countries of all. skills/professions.</p>
                <p style="margin-left: 10%; margin-right: 10%">Since its inception, it has gone from strength to strength with access to a database for all denominations. We are a deference recruiting company. We take a focused approach to all aspects of executive search and recruiting. Our experience and professionalism are manifested through our ability to provide local and international companies of all sizes with all their human resources needs, especially at GULF, through our highly experienced, capable and service-oriented staff, as well as manage workers in workplaces and provide them with a complete life. basic facilities with tools and equipment.</p>
                <p style="margin-left: 10%; margin-right: 10%">The search for suitable candidates for any required position begins with a careful and thorough analysis of potential applicants, paying special attention to merits that could match the job descriptions required by the client. Our Recruitment Task Force conducts preliminary interviews in such detail that little is left to chance.</p>
                <p style="margin-left: 10%; margin-right: 10%">We now look forward to providing you with any additional information you may require or visiting you to discuss various aspects of our services. We always hope to hear good news or more. If you have any ideas in mind, don't hesitate to ask. We are just a phone/fax/email away from you. Last but not least, all recruiting services come with a satisfaction guarantee.
                </p>

            </div>
        </div>


        <!--broken-section-->
        <section class="cmt-row broken-section bg-layer-equal-height clearfix">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col-lg-6">
                        <div class="cmt-bg cmt-col-bgcolor-yes cmt-left-span cmt-bgcolor-darkgrey spacing-6">
                            <div class="cmt-col-wrapper-bg-layer cmt-bg-layer"></div>
                            <div class="layer-content">
                                <div class="pl-15 mt-2 text-left res-991-pl-0 res-991-mt-15">
                                    <!-- section title -->
                                    <div class="section-title">
                                        <div class="title-header">
                                            <h5>ABOUT Visa</h5>
                                            <h2 class="title">Visa Services From <strong>Experienced Agents.</strong></h2>
                                        </div>
                                    </div><!-- section title end -->
                                    <p>At Ozone Manpower Overseas HR Management Consultancy Services we combine an intuitive understanding of your business needs with a focused approach and our knowledge of the current talent market. At Ozone Manpower Overseas HR we act as a gateway to provide a wide range of recruitment and selection services to companies. We are a dedicated team of professional consultants offering senior executive recruitment and selection services in Pakistan. <a class="cmt-textcolor-skincolor" href="contact-us-1.php">Read More</a></p>
                                    <div class="pt-10">
                                        <!-- cmt-progress-bar -->
                                        <div class="cmt-progress-bar" data-percent="92%">
                                            <div class="progressbar-title">Visa process</div>
                                            <div class="progress-bar-inner">
                                                <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                            </div>
                                            <div class="progress-bar-percent" data-percentage="92"></div>
                                        </div><!-- cmt-progress-bar end -->
                                        <!-- cmt-progress-bar -->
                                        <div class="cmt-progress-bar clearfix" data-percent="80%">
                                            <div class="progressbar-title">Study and work visa</div>
                                            <div class="progress-bar-inner">
                                                <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                            </div>
                                            <div class="progress-bar-percent" data-percentage="80"></div>
                                        </div><!-- cmt-progress-bar end -->
                                        <!-- cmt-progress-bar -->
                                        <div class="cmt-progress-bar clearfix" data-percent="88%">
                                            <div class="progressbar-title">buisness visit visa</div>
                                            <div class="progress-bar-inner">
                                                <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                            </div>
                                            <div class="progress-bar-percent" data-percentage="88"></div>
                                        </div><!-- cmt-progress-bar end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-12 mx-auto">
                        <!-- col-img-img-five -->
                        <div class="cmt-bg cmt-col-bgimage-yes col-bg-img-five cmt-right-span">
                            <div class="cmt-col-wrapper-bg-layer cmt-bg-layer"></div>
                            <div class="layer-content h-100">
                                <div class="col-lg-7 col-md-4 p-0 h-100">
                                    <div class="cmt-bgcolor-skincolor d-flex flex-column h-100 justify-content-between featured-icon-box icon-align-top-content style7">
                                        <div class="featured-content cmt-bgcolor-skincolor bor_rad_5">
                                            <div class="featured-title">
                                                <h5>The Future Of Bussiness <strong>Visa process.</strong></h5>
                                            </div>
                                        </div>
                                        <a class="cmt-btn btn-inline cmt-btn-size-sm cmt-icon-btn-left cmt-btn-color-white" href="contact-us-1.php" title=""><i class="fa fa-minus"></i>Contact us</a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- col-img-bg-img-five end-->
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--broken-section end-->



        <?php include 'include/footer.php';?>