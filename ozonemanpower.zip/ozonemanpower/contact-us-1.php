<?php include 'include/header.php';?>

        <div class="cmt-page-title-row">
            <div class="cmt-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="page-title-heading">
                                <h2 class="title">Contact Us</h2>
                                <p>Ozone Manpower</p>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="index.php">Home</a>
                                </span>
                                <span>Contact Us</span>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>                    
        </div>
        <!-- page-title end -->


     <!--site-main start-->
     <div class="site-main">

        <!--google_map-->
        <div id="google_map" class="google_map res-991-mt-30">
            <div class="map_container">
                <div id="map">
                
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13286.474650398684!2d73.07057626977539!3d33.64112829999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38df95e0f875b487%3A0x14fa0508ffd43eca!2sOzone%20Manpower%20Recruiting%20Agency!5e0!3m2!1sen!2s!4v1639561660322!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>


        <!--- conatact-section -->
        <section class="cmt-row conatact-section clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cmt-col-bgcolor-yes cmt-bg cmt-bgcolor-white z-index-2 spacing-7 box-shadow">
                            <div class="cmt-col-wrapper-bg-layer cmt-bg-layer"></div>
                            <div class="row ">
                                <div class="col-lg-4 col-md-5">
                                    <div class="cmt-bgcolor-darkgrey pt-30 pb-30 pl-30 pr-30">
                                        <div class="mb-20">
                                            <h4>Our Location</h4>
                                            <p>Office #7B 1st Floor Ali Arcade opp. Habib Bank 6th Road. Rawalpindi Pakistan.</p>
                                        </div>
                                        <h4>Quick Contact</h4>
                                        <div class="cmt-textcolor-white">Email: <a href="">ozoneoep@gmail.com</a></div>
                                        <div class="cmt-textcolor-white">Contact: <a href="">ozoneoep@gmail.com</a></div>
                                    </div>
                                    <div class="cmt-bgcolor-skincolor pt-30 pb-25 pl-30 pr-30">
                                        <h5 class="font-weight-normal">We will get back to you within 24 hours, or call us everyday, 09:00 AM - 12:00 PM</h5>
                                        <div class="d-flex align-items-center pt-10">
                                            <div class="cmt-icon cmt-icon_element-border cmt-icon_element-color-white cmt-icon_element-size-xs cmt-icon_element-style-rounded mb-10 mr-15">
                                                <i class="fa fa-phone"></i>
                                            </div>
                                            <h4>+051-2716770</h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-7">
                                    <div class="pl-30 res-991-pl-0 res-767-mt-30">
                                        <!-- section title -->
                                        <div class="section-title with-desc clearfix">
                                            <div class="title-header">
                                                <h5>why choose us</h5>
                                                <h2 class="title">Get In <strong>Touch?</strong></h2>
                                            </div>
                                        </div><!-- section title end -->
                                        <form class="contact_form wrap-form pt-15 clearfix" method="POST" novalidate="novalidate" action="" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-6">
                                                    <label>
                                                        <span class="text-input"><input name="name" type="text" value="" placeholder="Your Name" required="required"></span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label>
                                                        <span class="text-input"><input name="email" type="text" value="" placeholder="Your Email" required="required"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6 col-md-6">
                                                    <label>
                                                        <span class="text-input"><input name="phone" type="text" value="" placeholder="Phone Number" required="required"></span>
                                                    </label>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <label>
                                                        <span class="text-input"><input name="subject" type="text" value="" placeholder="Subject" required="required"></span>
                                                    </label>
                                                </div>
                                            </div>
                                               <div class="row">
                                                <div class="col-lg-6 col-md-6">
                                                    <label>
                                                        <span class="text-input"><input name="file" type="file" value="" required="required"></span>
                                                    </label>
                                                </div>
                                            </div>
                                            <label>
                                                <span class="text-input"><textarea name="message" rows="5" placeholder="Message" required="required"></textarea></span>
                                            </label>
                                            <button class="submit cmt-btn cmt-btn-size-lg cmt-btn-shape-rounded cmt-btn-style-border cmt-btn-color-dark w-100" name="send" type="submit">Submit Request !</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


        <?php
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        
        
        if(isset($_POST['send']))
        {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $subject = $_POST["subject"];
        $message = $_POST["message"];
        $file = $_FILES["file"];

        //Load Composer's autoloader
        require 'PHPMailer/Exception.php';
        require 'PHPMailer/PHPMailer.php';
        require 'PHPMailer/SMTP.php';

//Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);

try {
    //Server settings
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'mail.ozonemanpower.org';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'ceo@ozonemanpower.org';                     //SMTP username
    $mail->Password   = '03076999777_ceo';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom($email, 'Mailer');
    $mail->addAddress('ceo@ozonemanpower.org', 'Maple International');     //Add a recipient

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = "<b>Sender Name :</b> $name <br><b> Sender Emial:</b> $email <br><b> Sender Message : </b> $message";
    
        if ($file["size"] > 0) {
            $mail->addAttachment($file["tmp_name"], $file["name"]);
        }
        
    $mail->send();
    echo '<div class="success-message">Mail has been sent To HR Department</div>';
} catch (Exception $e) {
    print_r($e);
     echo '<div class="alert">Message could not be sent. Mailer Error: {$mail->ErrorInfo} </div>';
}
}
        
        ?>
              



        </section>
      
    </div> 

    <?php include 'include/footer.php';?>