        <!--footer start-->
        <footer class="footer cmt-bgcolor-darkgrey widget-footer clearfix">
        <div class="first-footer">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-5 widget-area">
                        <div class="widget widget_text mr-25 clearfix">
                            <h3 class="widget-title">About Us</h3>
                            <div class="textwidget widget-text">
                                <p>Ozone Manpower Recruiting Agency provides qualified and qualified personnel in countries where golf is played at all levels in the fields of consumer goods, engineering/construction, information technology, telecommunications, healthcare, finance, etc. </p>
                            </div>
                            <div class="cmt-horizontal_sep mt-25 mb-30"></div>
                            <div class="social-icons circle">
                                <ul class="list-inline cmt-textcolor-skincolor">
                                    <li class="social-facebook"><a class="tooltip-top" target="_blank" href="https://www.facebook.com/Ozone-Manpower-102513144791510/" data-tooltip="Facebook"><i class="ti ti-facebook"></i></a></li>
                                    <li class="social-twitter"><a class="tooltip-top" target="_blank" href="#" data-tooltip="twitter"><i class="ti ti-twitter-alt"></i></a></li>
                                    <li class="social-instagram"><a class="tooltip-top" target="_blank" href="https://mail.google.com/mail/u/3/#inbox" data-tooltip="Google"><i class="ti ti-google"></i></a></li>
                                    <li class="social-twitter"><a class="tooltip-top" target="_blank" href="https://www.linkedin.com/in/ozone-manpower-33a560217/" data-tooltip="Linkedin"><i class="ti ti-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area">
                        <div class="widget widget_nav_menu clearfix">
                           <h3 class="widget-title">Visa Services</h3>
                            <ul id="menu-footer-quick-links">
                                <li><a href="family-visa.php">Green card</a></li>
                                <li><a href="about-us.php">PR Applicants</a></li>
                                <li><a href="visitor-visa.php">Visa Consultancy</a></li>
                                <li><a href="about-us-2.php">Travel Insurance</a></li>
                                <li><a href="temporary-Work-visa.php">Work Permits</a></li>
                                <li><a href="student-visa.php">Abroad Study</a></li>
                                <li><a href="ielts.php">International Permit</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3 widget-area">
                        <div class="widget contact_map clearfix">
                            <h3 class="widget-title">Useful Links</h3>
                            <div class="footer_map mb-20">
                                <img src="images/footer_map.png" alt="">
                            </div>
                            <ul class="widget_contact_wrapper">
                                <li><i class="cmt-textcolor-skincolor fa fa-map-marker"></i>Office #7B 1st Floor Ali Arcade opp. Habib Bank 6th Road. Rawalpindi Pakistan</li>
                                <li><i class="cmt-textcolor-skincolor fa fa-phone"></i>+051-2716770</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-footer">
            <div class="container">
                <div class="row no-gutters">
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6><a href="">ozoneoep@gmail.com</a></h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Drop Us a Line</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text cmt-bgcolor-skincolor">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>+92 3076999777</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Call Us Now!</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-map-marker"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6>( Head Office ) Office #7-B 1st Floor Ali Arcade 6th Road. Rawalpindi-Pakistan</h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Get Direction</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-footer">
            <div class="container">
                <div class="row no-gutters">
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6><a href="">ozonemanpower711@gmail.com</a></h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Drop Us a Line</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text cmt-bgcolor-skincolor">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>+92 3084947880</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Call Us Now!</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-map-marker"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6>( Vehari Branch ) Office #G-1 Habib Arcade 28-D D-Block Club Road</h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Get Direction</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-footer">
            <div class="container">
                <div class="row no-gutters">
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6><a href="">zafar@ozonemanpower.org</a></h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Drop Us a Line</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text cmt-bgcolor-skincolor">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>+92 3000612567</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Call Us Now!</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                    <div class="widget-area col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <aside class="widget widget-text">
                            <!--featured-icon-box-->
                            <div class="featured-icon-box icon-align-before-content">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-square">
                                        <i class="fa fa-map-marker"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h6>( Vehari Branch ) Office #G-1 Habib Arcade 28-D D-Block Club Road</h6>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Get Direction</p>
                                    </div>
                                </div>
                            </div><!-- featured-icon-box end-->
                        </aside>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom-footer-text">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright text-center">
                            <div id="menu-footer-menu">
                                <ul class="footer-nav-menu text-center">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about-us.php">About</a></li>
                                    <li><a href="contact-us-1.php">Contact Us</a></li>
                                </ul>
                            </div>
                            <span>Copyright © 2021&nbsp;. All rights reserved.</span>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--footer end-->

        <!--back-to-top start-->
        <a id="totop" href="#top">
            <i class="fa fa-angle-up"></i>
        </a>
        <!--back-to-top end-->

    </div><!-- page end -->


    <!-- Javascript -->

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>    
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/jquery-validate.js"></script> 
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/numinate.min.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/jquery-isotope.js"></script>
    <script src="js/main.js"></script>

    <!-- Revolution Slider -->
    
    <script src="revolution/js/slider.js"></script>

    <!-- SLIDER REVOLUTION 6.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <script  src='revolution/js/revolution.tools.min.js'></script>
    <script  src='revolution/js/rs6.min.js'></script>

    <!-- Javascript end-->

</body>

<!-- Mirrored from www.cymolthemes.com/php//tripzia/home-3.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Nov 2021 18:00:58 GMT -->
</html>