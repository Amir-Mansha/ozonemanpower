
 

            <?php include 'include/header.php';?>
     <rs-module-wrap id="rev_slider_1_1_wrapper" data-source="gallery"> 
            <rs-module id="rev_slider_1_1" data-version="6.1.0"> 
                <rs-slides>

                    <rs-slide data-key="rs-1" data-title="Slide1" data-thumb="images/slides/slider-mainbg-001.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:3dcurtain-vertical;sl:d;"> 

                        <img src="images/pexels/pexels-anamul-rezwan-1116035.jpg" title="slider-bg-image" width="1920" height="690" class="rev-slidebg" data-no-retina>
                    
                        <rs-layer id="slider-1-slide-1-layer-1" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:230px,230px,119px,78px;" 
                            data-text="w:normal;s:20,20,18,18;l:20,20,18,18;a:left;fw:400;"
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:12,12,10,10;r:30,30,20,15;b:12,12,10,10;l:30,30,20,15;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-20deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-10deg;oY:0%;e:power4.in;st:500;sp:500;sR:200;" data-frame_999="st:w;sp:2000;sR:7500;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1000;sp:500;" 
                            style="z-index:50;background-color:rgba(255,255,255,.88);text-transform:uppercase;" >Welcome in Ozone Manpower
                        </rs-layer>

                        <rs-layer id="slider-1-slide-1-layer-2" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:285px,285px,169px,127px;" 
                            data-text="w:normal;s:59,59,49,36;l:60,60,50,38;a:left;fw:300;" 
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:15,15,14,12;r:30,30,20,20;b:15,15,14,12;l:30,30,20,20;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-10deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-5deg;oY:0%;e:power4.in;st:900;sp:500;sR:600;" data-frame_999="st:w;sp:2000;sR:7100;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1400;sp:500;" 
                            style="z-index:48;background-color:rgba(255,255,255,.88);font-family: 'Roboto', sans-serif; text-transform:uppercase;" >4474 |<strong class="cmt-textcolor-skincolor"> RWP </strong><strong class="cmt-textcolor-skincolor"></strong>
                        </rs-layer>

                        <a  id="slider-1-slide-1-layer-3" 
                            class="rs-layer cmt-btn cmt-btn-size-md cmt-btn-shape-round cmt-btn-style-fill cmt-btn-color-white"
                            href="contact-us-1.php"
                            target="_self" 
                            data-type="button" 
                            data-xy="x:l;xo:50px,20px,15px,10px;y:b,b,b,b;yo:230px,230px,117px,78px;"
                            data-rsp_ch="on"
                            data-color="#1d2143" 
                            data-text="s:15;a:c;fw:600;"
                            data-frame_0="y:50px;" 
                            data-frame_1="e:power4.out;st:900;sp:500;sR:900;" 
                            data-frame_999="st:w;sp:2000;sR:7600;"
                            data-frame_hover="c:#fff;bow:1px,1px,1px,1px;boc:#0067ed;bgc:#0067ed"
                            style="z-index:7;text-transform: capitalize;">Book Your Job!
                        </a>

                    </rs-slide> 

                    <rs-slides>

                    <rs-slide data-key="rs-1" data-title="Slide1" data-thumb="images/slides/slider-mainbg-001.jpg" data-anim="ei:d;eo:d;s:d;r:0;t:3dcurtain-vertical;sl:d;"> 

                        <img src="images/pexels/josue-isai-ramos-figueroa-qvBYnMuNJ9A-unsplash.jpg" title="slider-bg-image" width="1920" height="690" class="rev-slidebg" data-no-retina>
                    
                        <rs-layer id="slider-1-slide-1-layer-1" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:230px,230px,119px,78px;" 
                            data-text="w:normal;s:20,20,18,18;l:20,20,18,18;a:left;fw:400;"
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:12,12,10,10;r:30,30,20,15;b:12,12,10,10;l:30,30,20,15;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-20deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-10deg;oY:0%;e:power4.in;st:500;sp:500;sR:200;" data-frame_999="st:w;sp:2000;sR:7500;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1000;sp:500;" 
                            style="z-index:50;background-color:rgba(255,255,255,.88);text-transform:uppercase;" >Welcome in Ozone Manpower
                        </rs-layer>

                        <rs-layer id="slider-1-slide-1-layer-2" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:285px,285px,169px,127px;" 
                            data-text="w:normal;s:59,59,49,36;l:60,60,50,38;a:left;fw:300;" 
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:15,15,14,12;r:30,30,20,20;b:15,15,14,12;l:30,30,20,20;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-10deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-5deg;oY:0%;e:power4.in;st:900;sp:500;sR:600;" data-frame_999="st:w;sp:2000;sR:7100;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1400;sp:500;" 
                            style="z-index:48;background-color:rgba(255,255,255,.88);font-family: 'Roboto', sans-serif; text-transform:uppercase;" >4474 |<strong class="cmt-textcolor-skincolor"> RWP </strong><strong class="cmt-textcolor-skincolor"></strong>
                        </rs-layer>

                        <a  id="slider-1-slide-1-layer-3" 
                            class="rs-layer cmt-btn cmt-btn-size-md cmt-btn-shape-round cmt-btn-style-fill cmt-btn-color-white"
                            href="contact-us-1.php"
                            target="_self" 
                            data-type="button" 
                            data-xy="x:l;xo:50px,20px,15px,10px;y:b,b,b,b;yo:230px,230px,117px,78px;"
                            data-rsp_ch="on"
                            data-color="#1d2143" 
                            data-text="s:15;a:c;fw:600;"
                            data-frame_0="y:50px;" 
                            data-frame_1="e:power4.out;st:900;sp:500;sR:900;" 
                            data-frame_999="st:w;sp:2000;sR:7600;"
                            data-frame_hover="c:#fff;bow:1px,1px,1px,1px;boc:#0067ed;bgc:#0067ed"
                            style="z-index:7;text-transform: capitalize;">Book Your Job!
                        </a>

                    </rs-slide> 

                    <rs-slide data-key="rs-2" data-title="Slide2" data-thumb="images/slides/slider-mainbg-002.jpg" data-anim="ei:d;eo:d;s:2000ms;r:0;t:3dcurtain-horizontal;sl:d;">

                        <img src="images/pexels/pexels-kateryna-babaieva-3926851.jpg" title="slider-bg-image" width="1920" height="690" class="rev-slidebg" data-no-retina> 

                        <rs-layer id="slider-1-slide-2-layer-1" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:230px,230px,119px,78px;" 
                            data-text="w:normal;s:20,20,18,18;l:20,20,18,18;a:left;fw:400;"
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:12,12,10,10;r:30,30,20,15;b:12,12,10,10;l:30,30,20,15;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-20deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-10deg;oY:0%;e:power4.in;st:500;sp:500;sR:200;" data-frame_999="st:w;sp:2000;sR:7500;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1000;sp:500;" 
                            style="z-index:50;background-color:rgba(255,255,255,.88);text-transform:uppercase;" >Welcome in Ozone Manpower
                        </rs-layer>

                        <rs-layer id="slider-1-slide-2-layer-2" 
                            data-type="text" 
                            data-xy="xo:50px,20px,15px,10px;yo:285px,285px,169px,127px;" 
                            data-text="w:normal;s:59,59,49,36;l:60,60,50,38;a:left;fw:300;" 
                            data-color="#0b0c26" 
                            data-rsp_ch="on"
                            data-padding="t:15,15,14,12;r:30,30,20,20;b:15,15,14,12;l:30,30,20,20;" 
                            data-ford="frame_0;frame_1;frame_2;frame_999;" 
                            data-frame_0="x:100px,82px,62px,38px;sX:0.8;sY:0.8;rY:-10deg;oY:0%;" 
                            data-frame_1="x:50px,41px,31px,19px;sX:1.5;sY:1.5;rY:-5deg;oY:0%;e:power4.in;st:900;sp:500;sR:600;" data-frame_999="st:w;sp:2000;sR:7100;" 
                            data-frame_2="x:0px;sX:1;sY:1;rY:0deg;oX:50%;oY:0%;oZ:0;tp:600px;e:power4.out;st:1400;sp:500;" 
                            style="z-index:48;background-color:rgba(255,255,255,.88);font-family: 'Roboto', sans-serif; text-transform:uppercase;" >Staff    <strong class="cmt-textcolor-skincolor">Provider from </strong><strong class="cmt-textcolor-skincolor">Pakistan</strong>
                        </rs-layer>

                        <a  id="slider-1-slide-2-layer-3" 
                            class="rs-layer cmt-btn cmt-btn-size-md cmt-btn-shape-round cmt-btn-style-fill cmt-btn-color-white"
                            href="contact-us-1.php"
                            target="_self" 
                            data-type="button" 
                            data-xy="x:l;xo:50px,20px,15px,10px;y:b,b,b,b;yo:230px,230px,117px,78px;"
                            data-border="bos:solid;boc:#fff;bow:1px,1px,1px,1px;"
                            data-rsp_ch="on"
                            data-color="#1d2143" 
                            data-text="s:15;a:c;fw:600;"
                            data-frame_0="y:50px;" 
                            data-frame_1="e:power4.out;st:900;sp:500;sR:900;" 
                            data-frame_999="st:w;sp:2000;sR:7600;"
                            data-frame_hover="c:#fff;bow:1px,1px,1px,1px;boc:#0067ed;bgc:#0067ed"
                            style="z-index:7;text-transform: capitalize;">Book a Job!
                        </a>

                    </rs-slide> 
                </rs-slides> 
                <rs-progress class="rs-bottom" style="visibility: hidden !important;"></rs-progress> 
            </rs-module>
        </rs-module-wrap> 

        <!--site-main start-->
        <div class="site-main">

            <!--skill-section-->
            <section class="cmt-row skill-section clearfix">
                <div class="container">
                    <div class="row row-equal-height">
                        <div class="col-xl-6 col-lg-6 col-md-7 col-sm-7 mx-auto">
                            <div class="d-flex cmt-boxes-spacing-20px">
                                <div class="cmt-box-col-wrapper">
                                    <!-- ttm_single_image-wrapper -->
                                    <div class="ttm_single_image-wrapper">
                                        <img class="img-fluid" src="images/single-img-01.jpg" alt="single_01">
                                    </div>
                                </div>
                                <div class="cmt-box-col-wrapper">
                                    <!-- ttm_single_image-wrapper -->
                                    <div class="ttm_single_image-wrapper pb-20">
                                        <img class="img-fluid" src="images/single-img-02.jpg" alt="single_02">
                                    </div>
                                    <!-- ttm_single_image-wrapper -->
                                    <div class="ttm_single_image-wrapper">
                                        <img class="img-fluid" src="images/single-img-03.jpg" alt="single_03">
                                    </div>
                                </div>
                            </div>
                            <div class="m-auto cmt-textcolor-white pt-15 pb-0 mt_190 pr-30 pl-30 z-index-1 cmt-bgcolor-skincolor">
                                <a href="https://www.youtube.com/watch?v=9tDaE2e_8Fs" target="_self" class="cmt_prettyphoto">
                                    <div class="d-flex align-items-center">
                                        <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-white cmt-icon_element-size-sm mb-15 mr-2">
                                            <i class="ti ti-control-play"></i>
                                        </div><h5>Working Since 2007</h5>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-xs-12">
                            <div class="pl-15 mt-15 text-left res-991-pl-0 res-991-mt-15">
                                <!-- section title -->
                                <div class="section-title">
                                    <div class="title-header">
                                        <h5>About Company </h5>
                                        <h2 class="title">Ozone Manpower <strong></strong></h2>
                                    </div>
                                    <div class="title-desc">Ozone Manpower obtained license in 2013 from Ministry of Labour, Manpower and Overseas Employment, Manpower Recruitment, Government of Pakistan to meet the increasing requirements. </div>
                                </div><!-- section title end -->
                                <div class="pt-10 pb-35">
                                    <!-- cmt-progress-bar -->
                                    <div class="cmt-progress-bar" data-percent="92%">
                                        <div class="progressbar-title">Executive Search and Recruitment </div>
                                        <div class="progress-bar-inner">
                                            <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                        </div>
                                        <div class="progress-bar-percent" data-percentage="92"></div>
                                    </div><!-- cmt-progress-bar end -->
                                    <!-- cmt-progress-bar -->
                                    <div class="cmt-progress-bar clearfix" data-percent="80%">
                                        <div class="progressbar-title">Mobilization and Deployment </div>
                                        <div class="progress-bar-inner">
                                            <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                        </div>
                                        <div class="progress-bar-percent" data-percentage="80"></div>
                                    </div><!-- cmt-progress-bar end -->
                                    <!-- cmt-progress-bar -->
                                    <div class="cmt-progress-bar clearfix" data-percent="88%">
                                        <div class="progressbar-title">Trade Testing and Skills Development </div>
                                        <div class="progress-bar-inner">
                                            <div class="progress-bar progress-bar-color-bar_skincolor"></div>
                                        </div>
                                        <div class="progress-bar-percent" data-percentage="88"></div>
                                    </div><!-- cmt-progress-bar end -->
                                </div>
                                <p class="mb-0">The Foundation was born from a small idea that arose in the minds of its promoters in 2007! We guide qualified applicants through their visa process in any country in which they seek to settle.<a class="cmt-textcolor-skincolor" href="contact-us-1.php">Read More</a></p>
                            </div>
                        </div>
                    </div><!-- row end -->
                </div>
            </section>
            <!--skill-section-->


            <!--cat-section-->
            <section class="cmt-row cat-section cmt-bgcolor-darkgrey bg-img2 cmt-bg cmt-bgimage-yes cmt-bg-pattern clearfix top-bottom">
                <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
                <div class="container">
                    <!-- row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- section title -->
                            <div class="section-title title-style-center_text">
                                <div class="title-header mt-5">
                                    <h5>what we do</h5>
                                    <h2 class="title">We Provide Experts Create Great<br> Value for<strong> Visa Categories</strong></h2>
                                </div>
                            </div><!-- section title end -->
                        </div>
                    </div><!-- row end -->
                    <!-- row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="featuredbox-number">
                                <div class="row slick_slider" data-slick='{"slidesToShow": 4, "slidesToScroll": 4, "arrows":false, "autoplay":true, "infinite":false, "responsive": [{"breakpoint":991,"settings":{"slidesToShow": 3}}, {"breakpoint":678,"settings":{"slidesToShow": 2}}, {"breakpoint":460,"settings":{"slidesToShow": 1}}]}'>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box style1 icon-align-top-content bor_rad_5">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-lg">
                                                    <i class="flaticon-bussiness-man"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5>Skilled Worker Visa</h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>For the persons whose jobs require a minimum work experience.</p>
                                                </div>
                                                <div class="cmt-di_links">
                                                    <a href="diplomatic-Offical-visa.php" class="di_link">
                                                        <i class="ti ti-angle-right"></i>
                                                    </a>
                                                    <span class="di_num">
                                                        <i class="cmt-num ti-info"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box style1 icon-align-top-content bor_rad_5">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-lg">
                                                    <i class="flaticon-passport-6"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5>Business Visa</h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>People who want to invest in or about to start businesses abroad.</p>
                                                </div>
                                                <div class="cmt-di_links">
                                                    <a href="business-visa.php" class="di_link">
                                                        <i class="ti ti-angle-right"></i>
                                                    </a>
                                                    <span class="di_num">
                                                        <i class="cmt-num ti-info"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box style1 icon-align-top-content bor_rad_5">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-lg">
                                                    <i class="flaticon-passport-14"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5>Work Permit</h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>To work refers to manage systems used to ensure that work is done nicely.</p>
                                                </div>
                                                <div class="cmt-di_links">
                                                    <a href="temporary-Work-visa.php" class="di_link">
                                                        <i class="ti ti-angle-right"></i>
                                                    </a>
                                                    <span class="di_num">
                                                        <i class="cmt-num ti-info"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box style1 icon-align-top-content bor_rad_5">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-lg">
                                                    <i class="flaticon-visa-1"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h6>Construction Recruitment Agency</h6>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>For the permanent residents visa documents issued under to immigration.</p>
                                                </div>
                                                <div class="cmt-di_links">
                                                    <a href="family-visa.php" class="di_link">
                                                        <i class="ti ti-angle-right"></i>
                                                    </a>
                                                    <span class="di_num">
                                                        <i class="cmt-num ti-info"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box style1 icon-align-top-content bor_rad_5">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-lg">
                                                    <i class="flaticon-graduation-hat"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5>Medical Recruitment Agency</h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>We provide efficient hardworking and skilled manpower for medical and health care industry</p>
                                                </div>
                                                <div class="cmt-di_links">
                                                    <a href="student-visa.php" class="di_link">
                                                        <i class="ti ti-angle-right"></i>
                                                    </a>
                                                    <span class="di_num">
                                                        <i class="cmt-num ti-info"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- row end -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="text-center mt-35 mb_20 res-991-mt-20">
                                <h6><span  class="font-weight-normal">Don’t Hesitate, Contact us for Better Help and Services.</span> <u><a class="cmt-textcolor-skincolor" href="contact-us-1.php">Explore all visa Categories.</a></u></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--cat-section-->


            <!--testimonial-section-->
            <section class="cmt-row testimonial-section clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-xs-12">
                            <div class="pt-15 res-991-pt-0">
                                <!-- section title -->
                                <div class="section-title">
                                    <div class="title-header">
                                        <h5>ABOUT AGENCY</h5>
                                        <h2 class="title"><strong>Overseas Employement</strong> Promoters Agents.</h2>
                                    </div>
                                </div><!-- section title end -->
                                <p>It is our explicit policy to provide services to customers that meet expectations in accordance with the highest standards of quality satisfaction. </p>
                                <div class="featuredbox-number">
                                    <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-skincolor cmt-icon_element-size-xs cmt-icon_element-style-rounded"> 
                                                <i class="cmt-num ti-info"></i>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>We modify whole system</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>Hire talented manpower quickly and within your budget for differents companies.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                     <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-skincolor cmt-icon_element-size-xs cmt-icon_element-style-rounded"> 
                                                <i class="cmt-num ti-info"></i>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>Safeguard for Your Bussiness</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>Our experience and professionalism is manifested through our ability to provide services to local and international companies.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                     <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-skincolor cmt-icon_element-size-xs cmt-icon_element-style-rounded"> 
                                                <i class="cmt-num ti-info"></i>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>Beneficial Strategies </h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>Our recruitment services care about the satisfaction of both candidates and employers.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="testimonials-nav z-index-2" >
                                <div class="testimonial-nav_item">
                                    <div class="nav_item">
                                        <img class="img-fluid" src="images/testimonial/nav-01.jpg" alt="testimonial-nav_item">
                                    </div>
                                </div>
                                <div class="testimonial-nav_item">
                                    <div class="nav_item">
                                        <img class="img-fluid" src="images/testimonial/nav-02.jpg" alt="testimonial-nav_item">
                                    </div>
                                </div>
                                <div class="testimonial-nav_item">
                                    <div class="nav_item">
                                        <img class="img-fluid" src="images/testimonial/nav-03.jpg" alt="testimonial-nav_item">
                                    </div>
                                </div>
                                <div class="testimonial-nav_item">
                                    <div class="nav_item">
                                        <img class="img-fluid" src="images/testimonial/nav-04.jpg" alt="testimonial-nav_item">
                                    </div>
                                </div>
                            </div>
                            <div class="cmt-col-bgcolor-yes cmt-bgcolor-skincolor cmt-col-bgimage-yes cmt-bg col-bg-img-one cmt-right-span cmt-bg-pattern spacing-1">
                                <div class="cmt-col-wrapper-bg-layer cmt-bg-layer">
                                    <div class="cmt-col-wrapper-bg-layer-inner"></div>
                                </div>
                                <div class="layer-content">
                                    <div class="testimonials-info">
                                        <!-- testimonials -->
                                        <div class="testimonials">
                                            <div class="testimonial-avatar">
                                                <div class="testimonial-img">
                                                    <img class="img-fluid" src="images/testimonial/01.jpg" alt="testimonial-img">
                                                </div>
                                            </div>
                                            <div class="testimonial-content">
                                                <blockquote class="testimonial-text">I would really appreciate Ozone Manpower and the entire team especially Mr. Ashiq Mansha for helping me get my medical visa for Saudi Arabia company. He helped me at all times to find the companies and the correct form. He was there for me throughout the entire process. </blockquote>
                                                <div class="testimonial-bottom">
                                                    <div class="testimonial-caption cmt-textcolor-white">
                                                        <h5>Muhammad Kashif</h5>
                                                        <label>(maneger 7 Founder)</label>
                                                    </div>
                                                    <div class="star-ratings">
                                                        <ul class="rating">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- testimonials end -->
                                        <!-- testimonials -->
                                        <div class="testimonials"> 
                                            <div class="testimonial-avatar">
                                                <div class="testimonial-img">
                                                    <img class="img-fluid" src="images/testimonial/02.jpg" alt="testimonial-img">
                                                </div>
                                            </div>
                                            <div class="testimonial-content">
                                                <blockquote class="testimonial-text">Ashiq Mansha has been associated with this field for more than last 8 years. He has enjoyed an efficient career and has worked with over 100 multinational organizations recruiting him. </blockquote>
                                                <div class="testimonial-bottom">
                                                    <div class="testimonial-caption cmt-textcolor-white">
                                                        <h5>Ashiq Sukhera</h5>
                                                        <label>About CEO</label>
                                                    </div>
                                                    <div class="star-ratings">
                                                        <ul class="rating">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- testimonials end -->
                                        <!-- testimonials -->
                                        <div class="testimonials"> 
                                            <div class="testimonial-avatar">
                                                <div class="testimonial-img">
                                                    <img class="img-fluid" src="images/testimonial/03.jpg" alt="testimonial-img">
                                                </div>
                                            </div>
                                            <div class="testimonial-content">
                                            <blockquote class="testimonial-text">I would really appreciate Ozone Manpower and the entire team especially Ms. Ashiq Mansha for helping me get my work visa for the organization. He helped me at all times to find the right form and organization. He was there for me throughout the entire process.</blockquote>
                                                <div class="testimonial-bottom">
                                                    <div class="testimonial-caption cmt-textcolor-white">
                                                        <h5>Ozone Manpower</h5>
                                                        <label>(CEO) OF company</label>
                                                    </div>
                                                    <div class="star-ratings">
                                                        <ul class="rating">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- testimonials end -->
                                        <!-- testimonials -->
                                        <div class="testimonials"> 
                                            <div class="testimonial-avatar">
                                                <div class="testimonial-img">
                                                    <img class="img-fluid" src="images/testimonial/04.jpg" alt="testimonial-img">
                                                </div>
                                            </div>
                                            <div class="testimonial-content">
                                                <blockquote class="testimonial-text">Ozone Manpower arranges for selected personnel to sign a foreign service agreement. This agreement is intended to satisfy applicable laws in the countries of origin and employment.</blockquote>
                                                <div class="testimonial-bottom">
                                                    <div class="testimonial-caption cmt-textcolor-white">
                                                        <h5>Services Agreement</h5>
                                                      
                                                    </div>
                                                    <div class="star-ratings">
                                                        <ul class="rating">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- testimonials end -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--testimonial-section end-->


            <section class="cmt-row introduction-section cmt-bgcolor-grey cmt-bg cmt-bgimage-yes bg-img7 cmt-bg-pattern mt_60 res-991-mt-0 clearfix">
                <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-8 col-sm-11 mx-auto col-xs-12">
                            <!-- ttm_single_image-wrapper -->
                            <div class="ttm_single_image-wrapper mr-60 pt-60 res-991-pt-0 res-991-mr-0 position-relative">
                                <img class="img-fluid w-100" src="images/pexels/pexels-mathias-pr-reding-7108780.jpg" alt="single_04">
                                <!--featured-icon-box-->
                                <div class="featured-icon-box icon-align-top-content cmt-bgcolor-darkgrey style2">
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5>Ozone <span class="cmt-textcolor-skincolor"> Manpower</span></h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>Come For Your Bright Future</p>
                                        </div>
                                    </div>
                                    <a class="cmt-btn cmt-btn-size-sm cmt-icon-btn-left btn-inline cmt-btn-color-skincolor" href="contact-us-1.php" tabindex="0"><i class="fa fa-minus"></i>Contact Us</a>
                                </div><!-- featured-icon-box end-->
                            </div>
                        </div>
                        <div class="col-lg-6 col-xs-12">
                            <div class="pt-60">
                                <!-- section title -->
                                <div class="section-title">
                                    <div class="title-header">
                                        <h5>For Tour Intirely Help!</h5>
                                        <h2 class="title"><strong>Best Overseas | Recruitment</strong> agency in Pakistan</h2>
                                    </div>
                                </div><!-- section title end -->
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box icon-align-top-content style3">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-md">
                                                    <i class="flaticon-book-1"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5><a href="toefl.php">ENGINEERING STAFF</a></h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>We offer our clients better and more timely sustainable services and solutions through automation and adoption of techniques.</p>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box icon-align-top-content style3">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-md">
                                                    <i class="flaticon-policy"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h6><a href="pte.php">CONSTRUCTION STAFF</a></h6>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>We have a well-established commercial testing center and therefore maintain high standards to do good and qualified work. </p>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box icon-align-top-content style3">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-md">
                                                    <i class="flaticon-contract"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h5><a href="ielts.php">OIL & GAS INDUSTRY</a></h5>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>Ozone Manpower is well managed and has a large recruiting center that is completely satisfied with its professionalism.</p>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <!--featured-icon-box-->
                                        <div class="featured-icon-box icon-align-top-content style3">
                                            <div class="featured-icon">
                                                <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-md">
                                                    <i class="flaticon-certificate"></i>
                                                </div>
                                            </div>
                                            <div class="featured-content">
                                                <div class="featured-title">
                                                    <h6><a href="gmat.php">ENGINEERS Recuritment</a></h6>
                                                </div>
                                                <div class="featured-desc">
                                                    <p>We deal with heavy engineers such as civil and civil engineers, oil and gas engineers, mechanical engineers and the like..</p>
                                                </div>
                                            </div>
                                        </div><!-- featured-icon-box end-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- row end -->
                </div>
            </section>


            <!--blog-section-->
            <section class="cmt-row blog-section clearfix">
                <div class="container">
                    <!-- row -->
                    <div class="row">
                        <div class="col-lg-7 m-auto">
                            <!-- section title -->
                            <div class="section-title title-style-center_text">
                                <div class="title-header">
                                    <h5>Best Overseas </h5>
                                    <h2 class="title"> Recruitment agency in <strong> Pakistan</strong></h2>
                                </div>
                            </div><!-- section title end -->
                        </div>
                    </div><!-- row end -->
                    <!-- slick_slider -->
                    <div class="row">
                        <div class="col-lg-6 col-md-5 col-sm-12">
                            <div class="blog-info">
                                <div class="blog-info_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="featured-imagebox featured-imagebox-post style1 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-four-720X620.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">We Help You To Find Your Dream Work Force!</a></h5>
                                            </div>
                                            <div class="post-desc featured-desc">
                                            <p>With our reliable services, we provide professional and skilled employees to other companies.</p>
                                        </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-info_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="featured-imagebox featured-imagebox-post style1 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/pexels-pixabay-159306.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">Perks Of Having Ozone Manpower At Your Back</a></h5>
                                            </div>
                                            <div class="post-desc featured-desc">
                                            <p>With over 14 years of experience, we are the most remarkable recruitment agency in Pakistan</p>
                                        </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-info_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="featured-imagebox featured-imagebox-post style1 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-one-760x580.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">Employment Insurance for Foreign Nationals</a></h5>
                                            </div>
                                            <div class="post-desc featured-desc">
                                            <p>EI system includes all citizens, permanent residents &amp; foreigners on work permits</p>
                                        </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-info_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="featured-imagebox featured-imagebox-post style1 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-three-720X620.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">We save client time by fulfilling all the required recruitment process</a></h5>
                                            </div>
                                            <div class="post-desc featured-desc">
                                            <p>Ozone Manpower, one of the top recruitment agencies in Gulf and Central Europe</p>
                                        </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-info_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="featured-imagebox featured-imagebox-post style1 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/pexels-andrea-piacquadio-3756678.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">You Will Become As lor Small And Your and Desire.</a></h5>
                                            </div>
                                            <div class="post-desc featured-desc">
                                            <p>We hold a strong mutual relation with international clients</p>
                                        </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-7 col-sm-12">
                            <div class="blog-nav">
                                <div class="blog-nav_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="d-flex align-items-center featured-imagebox featured-imagebox-post style2 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-four-720X620.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="post-top cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">We Help You To Find Your Dream Work Force!</a></h5>
                                            </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-nav_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="d-flex align-items-center featured-imagebox featured-imagebox-post style2 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/pexels-pixabay-159306.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="post-top cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">Perks Of Having Ozone Manpower At Your Back</a></h5>
                                            </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-nav_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="d-flex align-items-center featured-imagebox featured-imagebox-post style2 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-one-760x580.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="post-top cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">Employment Insurance for Foreign Nationals</a></h5>
                                            </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-nav_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="d-flex align-items-center featured-imagebox featured-imagebox-post style2 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/blog-three-720X620.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="post-top cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">We are good at saving our clients time by fulfilling all the required recruitment process</a></h5>
                                            </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                                <div class="blog-nav_item">
                                    <!-- featured-imagebox-post -->
                                    <div class="d-flex align-items-center featured-imagebox featured-imagebox-post style2 bor_rad_5">
                                        <div class="cmt-post-thumbnail featured-thumbnail"> 
                                            <img class="img-fluid" src="images/pexels/pexels-andrea-piacquadio-3756678.jpg" alt="image">
                                        </div>
                                        <div class="featured-content featured-content-post">
                                            <div class="post-top cmt-post-link">
                                                <div class="post-meta">
                                                    <span class="cmt-meta-line tags-links"><i class="fa fa-comments"></i>Comments</span>
                                                    <span class="cmt-meta-line byline"><i class="fa fa-user"></i>Admin</span>
                                                    <span class="cmt-meta-line post-date"><i class="fa fa-calendar"></i>12 Apr 2019</span>
                                                </div>
                                            </div>
                                            <div class="post-title featured-title">
                                                <h5><a href="blog-single.php" tabindex="0">You Will Become As lor Small And Your and Desire.</a></h5>
                                            </div>
                                        </div>
                                    </div><!-- featured-imagebox-post end-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--blog-section end-->


        </div><!--site-main end-->

            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->


            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->


            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->


            <!--<div class="row logos-block">-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--    <div class="col-md-3 col-6">-->
            <!--        <img class="client-logo" src="images/ozone_logo.png" alt="logo-img">-->
            <!--    </div>-->
            <!--</div>-->

            <?php include 'include/footer.php';?>