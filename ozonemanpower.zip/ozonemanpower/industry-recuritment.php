<?php include 'include/header.php';?>

        <!-- page-title -->
        <div class="cmt-page-title-row">
            <div class="cmt-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="page-title-heading">
                                <h2 class="title">Industry Recuritment Agency</h2>
                                <p>Hire Engineers, managers, Oil rig Worker and labours</p>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="index.php">Home</a>
                                </span>
                                <span>Industry Recuritment Agency</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                    
        </div>
        <!-- page-title end -->


    <!--site-main start-->
    <div class="site-main">

        <div class="cmt-row sidebar cmt-sidebar-left cmt-bgcolor-white clearfix">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-lg-4 ttm-col-bgcolor-yes cmt-bg cmt-left-span cmt-bgcolor-grey mt_80 pt-60 mb_80 pb-60 res-991-mt-0 res-991-pt-0 widget-area sidebar-left">
                        <div class="cmt-col-wrapper-bg-layer cmt-bg-layer"></div>
                        <aside class="widget widget-nav-menu">
                            <ul class="widget-menu">
                                <li class="active"><a href="industry-recuritment.php">Industry Recuritment</a></li>
                                <li><a href="medical-agency.php">Medical Recuritment</a></li>
                                
                            </ul>
                        </aside>
                        <aside class="widget widget-download">
                            <ul class="download">
                            <a href="Ozone_profile_2.9 mb.pdf"> <li><i class="fa fa-file-pdf-o"></i><div><h4>Company Profile</h4>Download PDF</div></li></a>
                                
                            </ul>
                        </aside>
                        <aside class="widget widget-contact">
                            <img class="img-fluid" src="images/single-img-12.jpg" alt="single_12">
                            <div class="cmt-col-bgcolor-yes cmt-bgcolor-skincolor cmt-bg pt-20 pl-20 pr-20 pr-20 pb-20">
                                <div class="cmt-col-wrapper-bg-layer cmt-bg-layer">
                                    <div class="cmt-col-wrapper-bg-layer-inner"></div>
                                </div>
                                <div class="layer-content">
                                    <p class="mb-10">Our Appoinment Service Call Us</p>
                                    <h4><i class="flaticon-call mr-3"></i>+92-51-4933441</h4>
                                </div>
                            </div>
                        </aside>
                        <aside class="widget widget-form with-title">
                            <h3 class="widget-title">Contact Us</h3>
                            <?php
                 if(isset($_POST['submit'])){
                    $to = "sukhera745@gmail.com";
                    $name = $_POST['name'];
                    $from = $_POST['email'];
                    $search_category = $_POST['search_category'];
                     
                    $message = 'Name: '.$name.' Vissa Selected: '.$search_category.' Message: '.$_POST['message'];
                      
                      $headers = "From: $from";
                      if(mail($to, '',  $message, $headers)) {
                      echo "The email message was sent.";
                      } else {
                        echo "The email message was not sent.";
                      }

                 }
                ?>
                            <form id="immigration_form" class="immigration_form wrap-form clearfix" method="post" novalidate="novalidate" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <label>
                                    <span class="text-input"><input name="name" type="text" value="" placeholder="Your" required="required"></span>
                                </label>
                                <label>
                                    <span class="text-input"><input name="phone" type="text" value="" placeholder="Phone" required="required"></span>
                                </label>
                                <label>
                                    <span class="text-input">
                                        <select id="search_category" name="search_category" aria-invalid="false">
                                            <option value="Select Visa">Select Visa</option>
                                            <option value="Select Visa">Select Visa</option>
                                            <option value="Industry Recuritment">Industry Recuritment</option>
                                            <option value="Medical Recuritment">Medical Recuritment</option>
                                            
                                        </select>
                                    </span>
                                </label>
                                <label>
                                    <span class="text-input"><textarea name="message" rows="4" placeholder="Message" required="required"></textarea></span>
                                </label>
                                <button class="submit cmt-btn cmt-btn-size-md cmt-btn-shape-rounded cmt-btn-style-fill cmt-btn-color-skincolor" name="submit" type="submit">Send A Message</button>
                            </form>
                        </aside>
                    </div>


      




                    <div class="col-lg-8 content-area">
                        <div class="cmt-service-single-content-area">
                            <div class="cmt-featured-wrapper mb-40 res-991-mb-20">
                                <img class="img-fluid" src="images/pexels/luke-besley-k5l-zbRSPds-unsplash.jpg" alt="">
                            </div>
                            <div class="cmt-service-description">
                                <h4>infrastructure Plan & Visa Managment</h4>
                                <p>We take care of getting the best treatment for the client until the end of the contract. We advertise to find the right people as needed. CVs are compiled and edited by our experts who provide expertise in handling these tasks. Our services have been recognized by the Government of Pakistan, which has announced one of the best people export agencies in four years. This brave victory belongs to the only office built in Pakistan, where all operations are carried out under one roof. Our main services include.</p>
                                <div class="mt-30 mb-30 cmt-bgcolor-white box-shadow pt-20 pb-15 pl-30 res-991-pl-15 pr-15">
                                    <div class="row cmt-vertical_sep">
                                        <div class="col-lg-4 col-md-4 col-sm-6 cmt-box-col-wrapper">
                                            <!-- cmt-fid -->
                                            <div class="cmt-fid inside cmt-fid-with-icon cmt-fid-view-lefticon">
                                                <div class="cmt-fid-icon-wrapper cmt-textcolor-skincolor">
                                                    <i class="fa fa-calendar"></i>
                                                </div>
                                                <div class="cmt-fid-contents">
                                                    <h4 class="cmt-fid-inner">
                                                        <span   data-appear-animation="animateDigits" 
                                                                data-from="0" 
                                                                data-to="14" 
                                                                data-interval="3" 
                                                                data-before="" 
                                                                data-before-style="sup" 
                                                                data-after="" 
                                                                data-after-style="sub" 
                                                                class="numinate">14
                                                        </span>
                                                        <sub>+</sub>
                                                    </h4>
                                                    <h3 class="cmt-fid-title">Years Of Experience</h3>
                                                </div>
                                            </div><!-- cmt-fid end -->
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-6 cmt-box-col-wrapper">
                                            <!-- cmt-fid -->
                                            <div class="cmt-fid inside cmt-fid-with-icon cmt-fid-view-lefticon">
                                                <div class="cmt-fid-icon-wrapper cmt-textcolor-skincolor">
                                                    <i class="fa fa-smile-o"></i>
                                                </div>
                                                <div class="cmt-fid-contents">
                                                    <h4 class="cmt-fid-inner">
                                                        <span   data-appear-animation="animateDigits" 
                                                                data-from="0" 
                                                                data-to="1490" 
                                                                data-interval="15" 
                                                                data-before="" 
                                                                data-before-style="sup" 
                                                                data-after="" 
                                                                data-after-style="sub" 
                                                                class="numinate">1490
                                                        </span>
                                                        <sub>+</sub>
                                                    </h4>
                                                    <h3 class="cmt-fid-title">Happy Customers</h3>
                                                </div>
                                            </div><!-- cmt-fid end -->
                                        </div>
                                        <div class="col-lg-4 col-md-4 col-sm-4 cmt-box-col-wrapper">
                                            <!-- cmt-fid -->
                                            <div class="cmt-fid inside cmt-fid-with-icon cmt-fid-view-lefticon">
                                                <div class="cmt-fid-icon-wrapper cmt-textcolor-skincolor">
                                                    <i class="fa fa-user-plus"></i>
                                                </div>
                                                <div class="cmt-fid-contents">
                                                    <h4 class="cmt-fid-inner">
                                                        <span   data-appear-animation="animateDigits" 
                                                                data-from="0" 
                                                                data-to="850" 
                                                                data-interval="15" 
                                                                data-before="" 
                                                                data-before-style="sup" 
                                                                data-after="" 
                                                                data-after-style="sub" 
                                                                class="numinate">850
                                                        </span>
                                                        <sub>+</sub>
                                                    </h4>
                                                    <h3 class="cmt-fid-title">New Customers</h3>
                                                </div>
                                            </div><!-- cmt-fid end -->
                                        </div>
                                    </div>
                                </div>
                                <p>If you need construction, operation, maintenance of buildings, roads, camps, airports, hospitals, power plants, refining plants, factories and factory operations, etc. Whatever variety you need, we are honored to provide our services for you to choose from. required personnel in accordance with required standards. We have the scope to manufacture and deploy many professionals including engineers, medical staff, technicians and non-technical people at a time.</p>
                                <div class="mt-25 mb-25">
                                    <h4>Why Choose Us?</h4>
                                </div>
                                <div class="cmt-bgcolor-white box-shadow pt-40 pl-30 pb-40 pr-30 mb-30">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="ttm_single_image-wrapper res-991-pb-30">
                                                <img class="img-fluid" src="images/pexels/pexels-ave-calvar-martinez-4705093.jpg" alt="single_12">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <p>Ozone Manpower's connection with its candidates is to "never go off the rails." We assume all responsibility for the candidate and the candidate's information. From the initial interview to the personnel report, candidate information is stored in a database.</p>
                                            <ul class="cmt-list cmt-list-style-icon cmt-list-icon-color-skincolor pt-5">
                                                <li><i class="cmt-textcolor-skincolor fa fa-check-circle"></i><span class="cmt-list-li-content">Overseas Manpower Export</span>
                                                </li>
                                                <li><i class="cmt-textcolor-skincolor fa fa-check-circle"></i><span class="cmt-list-li-content">Skill Evaluation & Training Evaluation</span>
                                                </li>
                                                <li><i class="cmt-textcolor-skincolor fa fa-check-circle"></i><span class="cmt-list-li-content">Manpower Export Consultancy</span>
                                                </li>
                                                <li><i class="cmt-textcolor-skincolor fa fa-check-circle"></i><span class="cmt-list-li-content">Recruitment Management System for CV’s and data uploading and reporting.</span>
                                                </li>
                                                <li><i class="cmt-textcolor-skincolor fa fa-check-circle"></i><span class="cmt-list-li-content">Online Payroll Management System.</span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <p>The Ozone Manpower Management Recruitment Authority has played an important role in overseeing legal procedures and strict approval and identification procedures. As a result of our hard work and efforts, Ozone Manpower, Employment Agency has recognized the Ministry of Labor and Public Service of Pakistan to grant International Employment Service License No. 4474/RWP.</p>
                                <div class="pt-5 pb-5">
                                    <h4>Analyzing Visa services</h4>
                                </div>
                                <p>Visa Data Manager (VDM) is a best-in-class data storage, analytics and reporting platform, designed to collect and consolidate all of your card transaction data to make smarter, more likely business decisions. very useful. We are hiring these engineers on a recurring basis in Qatar, Saudi Arabia, Oman, Bahrain and Dubai. And we are also hiring these experts!!! </p>
                                <div class="accordion pt-15">
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#">Oil & Gas recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>The oil industry is the largest influencer in the global economy. Therefore, the importance of the oil and gas industry for the development of a country is evident. Energy is the main factor behind the success of any small and large industry and around 65% of the world's energy comes from oil and gas.
                                                <br>
                                            <img src="images/client/pexels-kindel-media-9889058.jpg" alt="" width="100%">
                                            <br>
With all these facts in mind, Ozone Manpower offers you cutting-edge recruiting solutions for all types of employees necessary for the success of your oil plant. We can provide super fast bulk labor all over the world. Our solutions adapt to the demand of the moment, industry demand and your company's policies.
                                             The oil and gas sector seeks highly skilled labor that can be deployed anywhere in the world. They need to be away from home for long periods and may have to face long exposures in seas, snowy fields, forests or deserts. Interpersonal communication becomes an important factor when people from diverse geographic and cultural backgrounds work together. Fortunately, we have successfully addressed all of these issues for our clients over the years.
                                             Hire talented labor for your oil and gas projects quickly and within your budget. Ozone Manpower brings you drilling engineers, chemical fluid drilling workers, and oil well field engineers to meet your technical needs in the field. We precisely understand your workforce needs and, with a long track record in oil and gas recruiting, we ensure you get the right candidates. We also offer long-term workforce solutions for your entire organization, so you can focus on productivity while we focus on finding you the right talent.

                                            </p>
                                            
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#">Construction recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>Infrastructure is the foundation of any industry. That is why construction is seen as the basis of progress. Roads, bridges, buildings, etc. They are symbols of prosperity and a prosperous society. This fast-paced world demands that construction projects be completed as soon as possible so that investors can start making profits as soon as possible. Natural calamities also play an important role in increasing construction activities and thus hiring construction labor.

                                            <br>

                                            <img src="images/client/pexels-anamul-rezwan-12165.jpg" alt="" width="100%">

                                            <br>

Ozone Manpower ensures that we understand your requirements and provide timely solutions for your manpower needs. We provide affordable and professional specialists in the construction industry and bulk labor in the form of construction workers. To provide timely services, we maintain a high-quality database of industry-specific skilled labor. In case of special needs, our expert consultants launch a specific skills search to find the right candidate for your needs.
                                               The demand for the construction industry is high on the global stage. Internal needs are also high. With this in mind, we have specialized recruitment solutions for this industry. Feel free to contact us for more customized manpower solutions or simply submit your vacancy here ozoneoep@gmail.com and we will reply as soon as possible.

                                            </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Shipping recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>The international shipping industry contributes approximately 90% of global trade. It has an immense contribution to the global economy, especially the global oil industry. The import and export of food and goods around the world largely depends on this industry. The export potential of a country is directly related to its transportation machinery. The shipping industry offers incredible career opportunities for people skilled and excited to work in this field. The industry is advanced and expects to hire qualified professionals with adequate efficiency and experience. Ozone Manpower is known for providing tremendous contracting solutions to its clients in the technical and commercial shipping sectors. We offer a diverse range of jobs including ship brokers, naval architects, charterers and technical superintendents. Professionals of all trades are needed here. Sales managers, entertainers, engineers, shipping crews, loading and unloading workers, heavy equipment operators, medical professionals, captains and many more.
                                            <br>

                                            <img src="images/client/pexels-julius-silver-753331.jpg" alt="" width="100%">
                                           <br>
                                           We carry out a proper selection procedure to select the right people. We hope to hire qualified professionals who are motivated, work hard and have a strong interest in working with this sector. Candidates with previous experience at sea or service in naval wings of their country's armed forces are given greater preference.
                                             Job duties can be divided into full-time and part-time. Ozone Manpower understands the shipping business and believes in building a strong relationship with its customers by providing the right people for the right job in a timely manner. You can contact us at hr.ozoneoep@gmail.com for more details.
 
                                        </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Hire expert talent for telecom industry</a></div>
                                        <div class="toggle-content">
                                            <p>Today, one of the fastest growing industries in the world is the telecommunications industry. The sector is highly competitive and with its wireless services it has been a revolution on the world stage. The fact that major multinational companies have shown their interest in investing in this industry has caused a boom in terms of economic growth and development.
                                            <br>

                                            <img src="images/client/pexels-igor-mashkov-6325003.jpg" alt="" width="100%">
                                            <br>
Be it a large or small establishment, the telecom sector is committed to offering immense employment opportunities. The telecommunications engineering sector is a leading sector with a wide range of occupations including systems engineer, data installation engineer, software engineers, project coordinator, electrical commissioning manager, quantity surveyor, construction workers towers and switching operations group technician.
                                              If you are looking for qualified young professionals in this sector, Ozone Manpower offers you world-class telecom recruitment solutions within the right time frame. We consider graduates with excellent communication skills and creativity to excel in this field. For IT and engineering jobs, we prefer professionals with strong technical knowledge.
                                              Our international clients are all popular telecommunications companies in Europe, Gulf countries, African countries and Southeast Asia. Feel free to contact ozonooep@gmail.com for more details./p>
                                        </div>
                                    </div><!-- toggle end -->
                                    
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Accounts & Finance recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>The real economy of a country depends greatly on the financial sector. With most European countries facing the worst recession in their history, the role of the financial sector in the global economy cannot be denied. The financial accounts and services industry is the most dynamic and vital component that regulates the global economy and keeps the recession under control.
                                            <br>

                                            <img src="images/client/pexels-mikhail-nilov-8297031.jpg" alt="" width="100%">
                                            <br>

                                           The accounts and finance sector has become one of the leading employment sectors offering a wide range of career opportunities. It is the most interesting field to work in times of industrial growth and development, where the allocation and use of funds is enormous.

                                              Ozone Manpower offers a suite of recruiting solutions comprised of qualified and experienced candidates around the world. The main job profiles we offer include accountants, financial services consultants, investment advisors, corporate directors, operations managers, transaction advisors and cashiers.

                                              Candidates must have in-depth knowledge of business, economics and their emerging fields. Ozone Manpower understands the requirements of its clients and carries out selection procedures along with interview sessions to select the right people. Preferred qualifications include MBA (finance), Chartered Accountants, Company Secretaries (CS), Master of Commerce, etc. Our team of experts hopes to meet the level of expectations of our clients within the stipulated time frame. You can contact us for more details at ozonooep@gmail.com


                                            </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Power Distribution recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>Electrical energy is a growing demand in today's world. Since the energy crisis is the main problem in the current period, the industry is definitely one of the leading sectors to have its impact on the global economy. Population growth and demand for better infrastructure have expanded the energy market. Energy transmission and distribution is a very interesting sector.
                                              The power distribution market is becoming very competitive with new initiatives and demand for more energy. This sector recruits a wide range of professionals ranging from field technicians to engineering personnel, including managers and directors.
                                            <br>

                                            <img src="images/client/pexels-anamul-rezwan-12165.jpg" alt="" width="100%">
                                            <br>

                                           Thermal, hydroelectric and nuclear power plants are the centers of energy production. Apart from that, energy distribution and management consumes a large part of the workforce in this sector.
                                              The most important areas for which we achieve the maximum demand for professionals are:
                                                <ul>
                                                <li>	Distribution and Transmission</li>
                                                <li>	Mechanical Engineering</li>
                                                <li>	Civil Engineering</li>
                                                <li>	Plant Design</li>
                                            </ul>
Ozone Manpower offers recruitment solutions for national and international clients. We ensure that we go through a proper selection procedure and training session to select the right candidates for their respective jobs. Candidates must possess good communication skills along with desired qualifications. They must be equipped to handle different machinery of international standards.
                                              This sector needs professionals who work long hours to meet the growing demand. Ozone Manpower Overseas offers to make such contracts to its clients within a specified period. If you have any questions, please contact us at ozonooep@gmail.com

 
                                           </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active"> Recuritment in Transport and Logistics Industry</a></div>
                                        <div class="toggle-content">
                                            <p>Ozone Manpower, a leading workforce recruitment agency, serves employers with the recruitment of transportation and logistics staff on a temporary, permanent and contract basis. Our contracting services offer innovative and cost-effective transportation and logistics solutions to our clients from different parts of the world. For more information related to efficient labor recruitment in the transportation and logistics industry, contact Ozone Manpower at ozoneoep@gmail.com
                                            <br>

                                            <img src="images/client/pexels-ivan-188679.jpg" alt="" width="100%">
                                            <br>
                                            
Our team of HR experts scans and selects the best candidate for your hiring needs. Our company's hiring process is strict and does not allow any reprieves. We help many companies and entrepreneurs in the logistics and transportation sector to hire driving and non-driving personnel. Our services include hiring efficient and hardworking candidates for the position of Forklift Operator, Warehouseman, Packer/Motor, Supervisor, Electrician, Machinery Operator, Rigger, Handler, Shunter, Manager, Dockhand and other related job profiles. .
                                              Our candidates are sincere, hardworking and honest towards their work and have proven themselves in their respective fields. With decent industry exposure and experience, candidates are aware of the latest trends and work in all directions to stand out. Our services are secure and care about the satisfaction of both employers and candidates. We hire from Pakistan. 

                                            
                                        </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Agriculture recuritment Agency</a></div>
                                        <div class="toggle-content">
                                            <p>Ozone Manpower, is a leading labor recruitment agency offering clients expert staffing solutions in the agricultural industry. We are determined to provide personal and specialized agricultural recruitment services to both employers and candidates. Many employers consider us the best choice for staffing needs due to our secure and reliable recruitment services. For more information related to hiring in the agricultural industry, please contact Ozone Manpower, at ozonooep@gmail.com
                                            <br>

                                            <img src="images/client/pexels-mark-stebnicki-2255801.jpg" alt="" width="100%">
                                                <br> 
                                               
Our expert HR team is highly qualified and experienced, and only those candidates who stand out from others with their knowledge, skills and experience are selected and sent. We currently serve employers with qualified candidates for the job profile of Agricultural Manager, Research Analyst, Agricultural or Agricultural Technician, Production Manager, Agricultural Engineer, Agricultural Officer, Agricultural Maintenance Supervisor and Sales Manager. For a candidate to work in the agricultural industry they must possess relevant education and decent work experience.
                                                 We understand the need for sustainable agriculture and recruit passionate and highly qualified candidates for different job profiles in the agricultural industry. Ozone Manpower serves employers around the world with its expert recruitment services. Our candidates are trained to give their best and prove to be an asset to the company and the employer.
                                                 For more information related to hiring in the agricultural industry, contact Ozone Manpower,

                                            </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Recuritment Services In Hospitality Industry</a></div>
                                        <div class="toggle-content">
                                            <p>
                                            <img src="images/client/pexels-tima-miroshnichenko-6195129.jpg" alt="" width="100%">
                                                <br> 
                                                <br>
                                           With over 10 years of recruiting experience for 5-star hotels, cruise ships and famous restaurants around the world, we are now leaders in hotel recruiting for the Gulf. Our clients in the Far East also return to us regularly for chefs, Pakistani cooks, hotel managers, seasonal workers, waiters, head chefs, etc. At Ozone Manpower, we understand the hospitality industry very well and offer manpower solutions exactly according to the requirements of a hotel, restaurant or cruise ship.
                                              Our large talent pool of experienced and successful hotel staff comes in handy when we have urgent needs. We have faster response times and a very high successful placement rate compared to most of our clients in this industry. Dedicated service, customer satisfaction and nominal service fee make us the preferred hotel recruitment agency for many international brands.
                                              Contact us at ozonooep@gmail.com and one of our experts will contact you to ensure your vacancies are filled sooner than expected.
                                           </p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle cmt-control-left-true">
                                        <div class="toggle-title"><a href="#" class="active">Surveillance and Security Staff recuritment and Training Agency</a></div>
                                        <div class="toggle-content">
                                            <p>Ozone Manpower is actively recruiting security and surveillance professionals for international positions. The majority of vacancies currently come from Qatar, United Arab Emirates, Singapore, Egypt, Turkey and the United Kingdom. In the Gulf countries, recently completed infrastructure projects increase the need for security professionals. If you are looking to hire any of the following professionals, please submit your requirement here (FREE) or contact us to know more about our services.
                                              CCTV operators
                                             <ul>
                                                 <li>CCTV operators & Surveillance Officers</li>
                                                 <li>Security, Surveillance Operations Manager, Head of Security</li>
                                                 <li>Security Supervisor, Security Officers & Guards</li>
                                                 
                                            </ul>
Candidates must post their resume here (FREE) to be considered for this job. It is mandatory to have a clean police record. There will be serious scrutiny of candidate backgrounds as we take this job of recruiting security and surveillance professionals very seriously.
                                              Our cost-effective workforce and facilities management solutions are preferred by employers around the world. If you would like to partner with us on international recruitment services, please contact us at ozonooep@gmail.com


                                            </p>
                                        </div>
                                    </div><!-- toggle end -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </div>

      
    </div><!--site-main end-->

    <?php include 'include/footer.php';?>