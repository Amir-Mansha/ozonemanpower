<?php include 'include/header.php';?>

        <!-- page-title -->
        <div class="cmt-page-title-row">
            <div class="cmt-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="page-title-heading">
                                <h2 class="title">Medical Recuritment Agency</h2>
                                <p>Ozone Manpower</p>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="index.php">Home</a>
                                </span>
                                <span>Doctors & Nurses</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                    
        </div>
        <!-- page-title end -->


    <!--site-main start-->
    <div class="site-main">

        
        <!--services_row-section-->
        <section class="cmt-row services_row-section clearfix top-bottom">
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <!-- section title -->
                        <div class="section-title title-style-center_text">
                            <div class="title-header">
                                <h5>WHAT WE DO</h5>
                                <h2 class="title">Medical Service <strong> Management</strong></h2>
                            </div>
                        </div><!-- section title end -->
                    </div>
                </div><!-- row end -->
                <!-- slick_slider -->
                <div class="row mb_15 slick_slider" data-slick='{"slidesToShow": 3, "slidesToScroll": 1, "arrows":false,  "dots":false, "autoplay":true, "centerMode":false, "centerPadding":0, "infinite":true, "responsive": [{"breakpoint":1100,"settings":{"slidesToShow": 3}} , {"breakpoint":777,"settings":{"slidesToShow": 2}}, {"breakpoint":500,"settings":{"slidesToShow": 1}}]}'>
                    <div class="cmt-box-col-wrapper col-lg-12">
                        <!--featured-imagebox-->
                        <div class="featured-imagebox featured-imagebox-services style2">
                            <div class="cmt-box-view-content-inner">
                                <!-- featured-thumbnail -->
                                <div class="featured-thumbnail">
                                    <a href="#" tabindex="-1"> <img class="img-fluid" src="images/Doctor/piron-guillaume-U4FyCp3-KzY-unsplash.jpg" alt="image"></a>
                                </div><!-- featured-thumbnail end-->
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5><a href="diplomatic-Offical-visa.php" tabindex="-1">Medical Laboratory Science</a></h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Certificate - On Campus.
                                        This area is needed for cell analysis to treat diseases.<p>
                                    </div>
                                </div>
                                <div class="bottom-footer">
                                    <a class="cmt-btn cmt-btn-size-md cmt-btn-shape-square cmt-btn-style-fill cmt-icon-btn-right cmt-btn-color-grey" href="team.php" tabindex="0">Read More<i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div><!-- featured-imagebox end-->
                    </div>
                    <div class="cmt-box-col-wrapper col-lg-12">
                        <!--featured-imagebox-->
                        <div class="featured-imagebox featured-imagebox-services style2">
                            <div class="cmt-box-view-content-inner">
                                <!-- featured-thumbnail -->
                                <div class="featured-thumbnail">
                                    <a href="#" tabindex="-1"> <img class="img-fluid" src="images/Doctor/usman-yousaf-pTrhfmj2jDA-unsplash.jpg" alt="image"></a>
                                </div><!-- featured-thumbnail end-->
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5><a href="business-visa.php" tabindex="-1">Doctors        </a></h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Doctors help patients when they get sick or injured and give them the best treatment possible.</p>
                                    </div>
                                </div>
                                <div class="bottom-footer">
                                    <a class="cmt-btn cmt-btn-size-md cmt-btn-shape-square cmt-btn-style-fill cmt-icon-btn-right cmt-btn-color-grey" href="team.php" tabindex="0">Read More<i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div><!-- featured-imagebox end-->
                    </div>
                    <div class="cmt-box-col-wrapper col-lg-12">
                        <!--featured-imagebox-->
                        <div class="featured-imagebox featured-imagebox-services style2">
                            <div class="cmt-box-view-content-inner">
                                <!-- featured-thumbnail -->
                                <div class="featured-thumbnail">
                                    <a href="#" tabindex="-1"> <img class="img-fluid" src="images/Doctor/pexels-anna-shvets-4167561.jpg" alt="image"></a>
                                </div><!-- featured-thumbnail end-->
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5><a href="student-visa.php" tabindex="-1">Nurses </a></h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Learn the basics of blood sample collection and be the hero behind the scenes in laboratory science.</p>
                                    </div>                                    
                                </div>
                                <div class="bottom-footer">
                                    <a class="cmt-btn cmt-btn-size-md cmt-btn-shape-square cmt-btn-style-fill cmt-icon-btn-right cmt-btn-color-grey" href="team.php" tabindex="0">Read More<i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div><!-- featured-imagebox end-->
                    </div>
                    <div class="cmt-box-col-wrapper col-lg-12">
                        <!--featured-imagebox-->
                        <div class="featured-imagebox featured-imagebox-services style2">
                            <div class="cmt-box-view-content-inner">
                                <!-- featured-thumbnail -->
                                <div class="featured-thumbnail">
                                    <a href="#" tabindex="-1"> <img class="img-fluid" src="images/Doctor/pexels-karolina-grabowska-6627926.jpg" alt="image"></a>
                                </div><!-- featured-thumbnail end-->
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5><a href="visitor-visa.php" tabindex="-1">Doctors & Nurses</a></h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>The nurse carries out any treatment that the doctor deems necessary, whether it is drawing blood, preparing meals, or working with medical equipment.</p>
                                    </div>
                                </div>
                                <div class="bottom-footer">
                                    <a class="cmt-btn cmt-btn-size-md cmt-btn-shape-square cmt-btn-style-fill cmt-icon-btn-right cmt-btn-color-grey" href="team.php" tabindex="0">Read More<i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div><!-- featured-imagebox end-->
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--services_row-section end-->


        <!---section-->
        <section class="cmt-row about_2-section cmt-bgcolor-grey clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 mx-auto">
                        <div class="ttm_single_image-wrapper">
                            <img class="img-fluid" src="images/Doctor/pexels-anna-shvets-4167542.jpg" alt="single_11">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="res-991-pt-30">
                            <!-- section title -->
                            <div class="section-title">
                                <div class="title-header">
                                    <h5>Ozone Manpower</h5>
                                    <h2 class="title">Medical Recuritment  <strong>Agency Service</strong></h2>
                                </div>
                                <div class="title-desc">Ozone Manpower (Overseas Specialists) to provide efficient, hard-working and skilled manpower for the medical and healthcare industry. We provide candidates with long-term contracts, term to term, per diem and direct hire. Our medical recruiting services are secure and we only send those candidates who excel in their field. For more information related to staffing solutions in the medical and healthcare industry, please contact Ozone Manpower ozoneoep@gmail.com
</div>
                            </div><!-- section title end -->
                            <p class="mb-20">Ozone Manpower Medical Recruitment agency aims to improve medical services by providing the right candidate for the right job. We sincerely work to maintain high standards of quality, professionalism and commitment in your company. Our recruitment services are appreciated by employers and candidates around the world. For more information related to hiring in the medical and healthcare industry, contact Ozone Manpower ozonooep@gmail.com</p>

                            <div class="featured-icon-box icon-align-before-content icon-ver_align-top style4">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-sm"> 
                                        <i class="fa fa-circle-o"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>01. Online Visa Services</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Medical recruitment agency aims to improve medical service by offering the right candidate for the right job.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="featured-icon-box icon-align-before-content icon-ver_align-top style4">
                                <div class="featured-icon">
                                    <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-skincolor cmt-icon_element-size-sm"> 
                                        <i class="fa fa-circle-o"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>02. Office worker</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p>Our recuritment services are appreciated by employers and candidates across the world.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--about-section end-->


    


       

        <!--services-section-->
        <section class="cmt-row services-section cmt-bgcolor-darkgrey bg-img5 cmt-bg cmt-bgimage-yes clearfix top-bottom">
            <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <!-- section title -->
                        <div class="section-title title-style-center_text">
                            <div class="title-header">
                                <h5>ABOUT AGENCY</h5>
                                <h2 class="title">An Expert Advisory For Great <br><strong>Value for Visa</strong></h2>
                            </div>
                        </div><!-- section title end -->
                    </div>
                </div><!-- row end -->
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="featuredbox-number">
                            <div class="row">
                                <div class="col-lg-3 col-md-6 col-sm-6">
                                    <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-top-content style6">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-white cmt-icon_element-size-md">
                                                <i class="ti ti-package"></i>
                                                <span class="fea_num cmt-textcolor-darkgrey">
                                                    <i class="cmt-num ti-info"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>Registration Online</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>You can register yourself online for our services. Fill up form details and we get back to you.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                </div>
                                <div class="col-lg-3 col-md-6 col-sm-6">
                                    <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-top-content style6">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-white cmt-icon_element-size-md">
                                                <i class="ti ti-package"></i>
                                                <span class="fea_num cmt-textcolor-darkgrey">
                                                    <i class="cmt-num ti-info"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>Documentation</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>Our experts suggest documentation submission as per country’s policy and applicant base.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                </div>
                                <div class="col-lg-3 col-md-6 col-sm-6">
                                    <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-top-content style6">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-white cmt-icon_element-size-md">
                                                <i class="ti ti-package"></i>
                                                <span class="fea_num cmt-textcolor-darkgrey">
                                                    <i class="cmt-num ti-info"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>We Will Call</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>After reviewing your documents we will get in touch with you for the next personal meeting for guidance.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                </div>
                                <div class="col-lg-3 col-md-6 col-sm-6">
                                    <!--featured-icon-box-->
                                    <div class="featured-icon-box icon-align-top-content style6">
                                        <div class="featured-icon">
                                            <div class="cmt-icon cmt-icon_element-onlytxt cmt-icon_element-color-white cmt-icon_element-size-md">
                                                <i class="ti ti-package"></i>
                                                <span class="fea_num cmt-textcolor-darkgrey">
                                                    <i class="cmt-num ti-info"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="featured-content">
                                            <div class="featured-title">
                                                <h5>Enjoy Your Freedom</h5>
                                            </div>
                                            <div class="featured-desc">
                                                <p>And you are all ready to apply. Professionals suggestions are always proven 100% guaranteed.</p>
                                            </div>
                                        </div>
                                    </div><!-- featured-icon-box end-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--services-section end-->


            <!--cta-section-->
            <section class="cmt-row cta_2-section bg-img6 cmt-bgcolor-skincolor cmt-bg cmt-bgimage-yes cmt-bg-pattern clearfix">
            <div class="container">
                <!-- row -->
                <div class="row align-items-center text-lg-left text-center">
                    <div class="col-xl-11 col-lg-11 col-md-12">
                        <div class="row-title mb-20 res-991-mb-30">
                            <!-- section title -->
                            <div class="section-title">
                                <div class="title-header">
                                    <h5>WE MAKE A DIFFERENCE</h5>
                                    <h2 class="title">The services of Ozone Manpower <strong>include the highest level of professionalism</strong></h2>
                                </div>
                            </div><!-- section title end -->
                            <a class="cmt-btn cmt-btn-size-md cmt-btn-shape-round cmt-btn-style-border cmt-btn-color-white mt-15 res-991-mt-10" href="contact-us-1.php">Contact Us</a>
                        </div>
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-12">
                        <div class="float-lg-right">
                            <a href="https://www.youtube.com/watch?v=9tDaE2e_8Fs" target="_self" class="cmt_prettyphoto">
                                <div class="cmt-icon cmt-icon_element-fill cmt-icon_element-color-darkgrey cmt-icon_element-size-sm cmt-icon_element-style-round mb-0">
                                    <i class="fa fa-play"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                </div><!-- row end -->
            </div>
        </section>
        <!--cta-section end-->


      
        <?php include 'include/footer.php';?>