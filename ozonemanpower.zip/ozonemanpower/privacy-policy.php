<html>
  
<head>
  <title>Ozone Manpower</title>
</head>
<style>
    h1 {
  color: black;
}

body {
  text-align: center;
  
}

#search[type=text] {
    width: 60%;
    height: 30px;
    margin-top: 25px;
}

nav {
  width: 98%;
  border: 1px solid blue;
  background-color: #66ccff;
  padding: 15px;
  text-decoration: none;
  margin-top: 25px;
  font-size: 30px;
}

nav a {
  text-decoration: none;
}

section {
  margin-top: 25px;
  
}

article {
  width: 70%;
  border: 1px solid black;
  background-color: #cccccc;
  padding: 15px;
  margin: 15%;
  margin-top: 5%;
  margin-bottom: 5%;
  font-size: 22px
}

p {
  font-size: 20px;
  line-height: 30px;
  text-align: left;
  
}


#social{
  width: 50%;
  border: 1px solid blue;
  background-color: #66ccff;
  padding: 15px;
  margin: 25%;
  margin-top: 3%;
  margin-bottom: 5%;
  font-size: 30px;
  
}

footer {
  width: 100%
  border: 1px;
  background-color: gray;
  font-size: 20px;
  padding: 30px
}
</style>
  
<body>
  <header>
      <h1>
        <a href="https://s.codepen.io/diegoarbito/debug/AXaQBo">
       Ozone Manpower
        </h1>
    <br>
    <img src="images/policy.png"/>
    
    <nav>
  
  <a href="#">Saudi Arabia</a> |
  <a href="#">United Arab Emirates (UAE)</a> |
  <a href="#">Qatar</a> |
  <a href="#">Kuwait</a> |
  <a href="#">Bahrain</a> |
  <a href="https://s.codepen.io/diegoarbito/debug/kXjYNq">Oman</a> 
  
  
  </nav>  

    <br>

    
  </header>
  

<section>
  
  <article>
    
 
    <h2> Privacy Policy </h2>
    
    <p>
        Ozone Manpower (“us”, “we”, or “our”) operates the website http://ozonemanpower.org/ (the “Service”).

        This page informs you of our policies regarding the collection, use and disclosure of Personal Information when you use our Service.
        
        We will not use or share your information with anyone except as described in this Privacy Policy.
       </p>
    
    <br>
      
    <h3> 1. Our Principles. </h3>
    
    <p>
    
<ul>
    <li>
        We do our utmost to protect user privacy through the appropriate use of security technology. This means: we ensure that we have appropriate physical and technological security measures to protect your information. We ensure that when we outsource any processes, the service provider has appropriate security measures.
    </li>
    <br>
    <li>
        We will respect your privacy. You should receive marketing emails only from Ozone Manpower and, if you choose, from carefully chosen third parties.
    </li>
    <br>
    <li>
        We may, however, email you occasionally with queries, for example, with reminders, warnings, or copyright requests.
    </li>
    <br>
    <li>
        We will collect and use individual user details only where we have legitimate business reasons and are legally entitled to do so.
    </li>
    <br>
    <li>
        We will be transparent in our dealings with you as to what information about you we will collect and how we will use your information.
    </li>
    <br>
    <li>
        We will use personal data only for the purpose(s) for which they were originally collected and we will ensure personal data are securely disposed of.
    </li>
    <br>
    <li>
        Our site is accessible via the Internet. This means that, wherever you choose to post your data on the site, it can be accessed from anywhere around the world.
    </li>
</ul>  
    </p>


    
    <br>
      
    <h3> 2. We use your Personal Information for providing and improving the service. By using the service, you agree to the collection and use of the information in accordance with this policy. </h3>
    
    <p>
    
        Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible at http://ozonemanpower.org/
    </p>
    
    <br>
      
    <h3> 3. Information Collection and Use
    </h3>
    
    <p>
    
        While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally, identifiable information may include, but is not limited to, your email address (“Personal Information”).
    </p>
    
    <br>
      
    <h3> 4. Public Information. </h3>
    
    <p>
    
      If you identify any User Information as public, you are authorizing us to share such information publicly. For example, you may elect to make certain Shared Information (such as your alias, bio, email or photos) publicly available. Also, there may be areas of the Services (e.g., message boards, discussion rooms, and other online forums) in which you are able to post information that will be available to all other users of the Services. By choosing to use these areas, you understand and agree that anyone may access, use, and disclose any information that you post to those areas.
      
    </p>
    
    <br>
      
    <h3> 5. Log Data </h3>
    
    <p>
    
        We collect information that your browser sends whenever you visit our Service (“Log Data”). This Log Data may consist of information such as your computer’s Internet Protocol (“IP”) address, browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, and other statistics.
      <br><br>
      In addition, we may use third-party services such as Google Analytics that collect, monitor, and analyze this type of information in order to increase our Service’s functionality. These third-party service providers have their own privacy policies addressing how they use such information.
 
    </p>
    
    <br>
      
    <h3> 6. Cookies </h3>
    
    <p>
    
        Cookies are files with a small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your computer’s hard drive
        <br>
        We use “cookies” to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service. 
    </p>
    
    <br>
      
    <h3> 7. Service Providers </h3>
    
    <p>
    
        We may employ third-party companies and individuals to facilitate our service, to provide the service on our behalf, to perform service-related services, or to assist us in analyzing how our service is used.
        <br>
        These third parties have access to your Personal Information only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
    </p>
    
    <br>
      
    <h3> 8. Communications </h3>
    
    <p>
    
        We may use your Personal Information to contact you with newsletters, marketing or promotional materials, and other information that may be of interest to you. You may opt-out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.


    </p>
    
    <br>
      
    <h3> 9. Compliance with Laws    </h3>
    
    <p>
        We will disclose your Personal Information where required to do so by law or subpoena or if we believe that such action is necessary to comply with the law and the reasonable requests of law enforcement or to protect the security or integrity of our service.
    </p>
    
    <br>
      
    <h3> 10. Security</h3>
    
    <p>
    
        The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.
    </p>
    
    <br>
      
    <h3> 11. International Transfer </h3>
    
    <p>
        Your information, including Personal Information, may be transferred to — and maintained on — computers located outside of your state, province, country, or other governmental jurisdiction where the data protection laws may differ from those of your jurisdiction.
        <br>
        If you are located outside Pakistan and choose to provide information to us, please note that we transfer the information, including Personal Information, to Pakistan and process it there.
<br>
Your consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.


    </p>
    
    <br>
      
    <h3> 12. Links to Other Sites </h3>
    
    <p>
        Our Service may contain links to other sites that are not operated by us. If you click on a third-party link, you will be directed to that third party’s site. We strongly advise you to review the Privacy Policy of every site you visit.
        <br>
        We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.


    </p>
    
    <br>
      
    <h3> 13. Children’s Privacy
    </h3>
    
    <p>
        Our Service does not address anyone under the age of 13 (“Children”).

        We do not knowingly collect personally identifiable information from children under 13. If you are a parent or guardian and you are aware that your Children have provided us with Personal Information, please contact us. If we become aware that we have collected Personal Information from children under the age of 13 without verification of parental consent, we take steps to remove that information from our servers.
    </p>
    
    <br>
      
    <h3> 14. Disclaimer for Press Releases: </h3>
    
    <p>
        ozonemanpower.org receives many press releases from PR Agencies, companies, media partners and other parties. We do do not accept any responsibility for the accuracy and completeness of the information provided in the press releases.
        <br>
        We reserve the right to make necessary changes in any PR (if required) and we also reserve the right to reject or remove old PRs anytime without advanced notice.
    </p>
    
    <br>
      
    <h3> 15. Changes to This Privacy Policy
 </h3>
    
    <p>
    
        We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
        <br>
        You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
    </p>

    <h1>Contact Us    </h1>

    <p>
        If you have any questions about this Privacy Policy, please contact us at ozoneoep@gmail.com
    </p>
  
  </article>
  
    
    
  
<footer>
  
  Copyright 2023 • <a href="http://ozonemanpower.org/">Privacy Policy</a> 

  
</footer>
    
  </body>
  
</html>