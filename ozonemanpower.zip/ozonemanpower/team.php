<?php include 'include/header.php';?>


        <!-- page-title -->
        <div class="cmt-page-title-row">
            <div class="cmt-page-title-row-inner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="page-title-heading">
                                <h2 class="title">Our Team</h2>
                                <p>Ozone Manpower </p>
                            </div>
                            <div class="breadcrumb-wrapper">
                                <span>
                                    <a title="Homepage" href="index.php">Home</a>
                                </span>
                                <span>Team</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                    
        </div>
        <!-- page-title end -->


    <!--site-main start-->
    <div class="site-main">

        <section class="cmt-row grid-section clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/team1.jpg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Ashiq Mansha</a></h5>
                                </div>
                                <div class="team-position">C.E.O Chairman</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/team2.jpeg" alt="image">
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Zafar Mansha</a></h5>
                                </div>
                                <div class="team-position">Business development manager/marketing manager</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/team3.jpeg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Kashif Mansha</a></h5>
                                </div>
                                <div class="team-position">Branch Manager Vehari Office</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/8.jpg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Adil Mansha</a></h5>
                                </div>
                                <div class="team-position">Ticketing Branch Manager Vehari Office</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                     <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/irfan.jpeg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Muhammad Irfan</a></h5>
                                </div>
                                <div class="team-position">Marketing Manager</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/6.jpg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Shahkeel Ahmed</a></h5>
                                </div>
                                <div class="team-position">Branch Manager Rawalpindi Office</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <!-- featured-imagebox-team -->
                        <div class="featured-imagebox featured-imagebox-team bor_rad_5">
                            <div class="cmt-team-box-view-overlay">
                                <div class="featured-iconbox cmt-media-link">
                                    <div class="media-block">
                                        <ul class="social-icons">
                                            <li class="social-twitter"><a href="#"><i class="ti ti-twitter-alt"></i></a></li>
                                            <li class="social-facebook"><a href="#"><i class="ti ti-facebook"></i></a></li>
                                            <li class="social-instagram"><a href="#"><i class="ti ti-instagram"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="featured-thumbnail">
                                    <img class="img-fluid" src="images/pexels/7.jpg" alt="image"> 
                                </div>
                            </div>
                            <div class="featured-content featured-content-team">
                                <div class="featured-title">
                                    <h5><a href="team-details.php">Muhammad faisal</a></h5>
                                </div>
                                <div class="team-position">Accountant Rawalpindi Office</div>
                            </div>
                        </div><!-- featured-imagebox-team end-->
                    </div>
                    
                    
                    
                </div>
            </div>
        </section>

      
    </div><!--site-main end-->

    <?php include 'include/footer.php';?>