<?php include 'include/header.php';?>


    <!--site-main start-->
    <div class="site-main">

        <section class="clearfix">
            <div class="container">
                <div class="row">

                <?php
// Your API URL
$apiUrl = 'https://gnews.io/api/v4/top-headlines?category=general&lang=en&country=gb&max=10&apikey=6e83a2f2f797ee3b0645f09d3c8fee2b';

// Fetch the API response
$apiResponse = file_get_contents($apiUrl);

// Decode the JSON response
$data = json_decode($apiResponse, true);

// Check if the response has articles
if (isset($data['articles']) && !empty($data['articles'])) {
    ?>
    <section class="section-news">
        <div class="container">
            <div class="header-section">
                <h3 class="small-title"><span></span>Recent News</h3>
                <h2 class="title">News & Articles</h2>
            </div>
            <div class="row">
                <?php
                // Loop through the articles
                foreach ($data['articles'] as $article) {
                    ?>
                    <div class="col-12 col-md-6">
                        <div class="single-news">
                            <a href="<?php echo $article['url']; ?>"><img src="<?php echo $article['image']; ?>" alt=""></a>
                            <div class="content">
                                <span class="date"><?php echo date('d M Y', strtotime($article['publishedAt'])); ?></span>
                                <h3 class="title"><a href="<?php echo $article['url']; ?>"><?php echo $article['title']; ?></a></h3>
                                <p class="text"><?php echo $article['description']; ?></p>
                                <span class="author">Source: <?php echo $article['source']['name']; ?></span>
                                <!-- Additional fields if needed -->
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </section>
    <?php
} else {
    // Handle the case when there are no articles
    echo 'No articles found.';
}
?>


                    
                    
                    
                </div>
            </div>
        </section>

      
    </div><!--site-main end-->

    <?php include 'include/footer.php';?>